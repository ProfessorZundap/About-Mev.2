function picklink() {
  var linknumber = 8;
  var linktext = "nolink.html";
  var linkselect = Math.floor(linknumber * Math.random()) + 1;
  if (linkselect == 1) {
    linktext = "https://www.youtube.com/watch?v=v5SSnQBtaq4";
  }
  if (linkselect == 2) {
    linktext = "https://www.youtube.com/watch?v=54oFGmCZSnY";
  }
  if (linkselect == 3) {
    linktext = "https://www.youtube.com/watch?v=du-TY1GUFGk";
  }
  if (linkselect == 4) {
    linktext = "https://www.youtube.com/watch?v=2sBFkfcB8WA";
  }

 if (linkselect == 5) {
    linktext = "https://www.youtube.com/watch?v=BW1aX0IbZOE";
  }

if (linkselect == 6) {
    linktext = "https://trumplings.com/";
}

if (linkselect == 7) {
    linktext = "https://smashthewalls.com";
  }
  
  if (linkselect == 8) {
   "https://cat-bounce.com" ;
  }
  return linktext;
}



window.onscroll = function() {myFunction()};


var navbar = document.getElementById("navbar");


var sticky = navbar.offsetTop;


function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}


